"""Pydantic schemas for DispatchGrid."""

