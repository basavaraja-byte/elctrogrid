"""API layer for DISPATCHGRID."""

