"""FastAPI application entrypoint for DISPATCHGRID."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse

from app.api.routes import customers, health, jobs, schedules, technicians
from app.core.config import settings
from app.core.exceptions import register_exception_handlers


def create_app() -> FastAPI:
    """Create and configure the DISPATCHGRID FastAPI application instance."""
    app = FastAPI(
        title=f"{settings.app_name} — Workforce Scheduling & Recovery Engine API",
        version="1.0.0",
        description=(
            "Canonical backend foundation for DISPATCHGRID integrating Electrical Workforce "
            "Management, Centralized Hard-Constraint Validation, Schedule Versioning, "
            "Human-Approved Recovery Proposals, and Persisted Before/After Metrics."
        ),
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    register_exception_handlers(app)

    @app.get("/", include_in_schema=False)
    def root_redirect() -> RedirectResponse:
        """Redirect root URL to interactive Swagger UI documentation."""
        return RedirectResponse(url="/docs")

    prefix = settings.api_v1_prefix
    app.include_router(health.router, prefix=prefix)
    app.include_router(customers.router, prefix=prefix)
    app.include_router(jobs.router, prefix=prefix)
    app.include_router(technicians.router, prefix=prefix)
    app.include_router(schedules.router, prefix=prefix)

    return app


app = create_app()

